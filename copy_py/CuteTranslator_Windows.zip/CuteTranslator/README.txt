МИ-МИ-МИ ПЕРЕВОДЧИК ДЛЯ ИГР

ПРЕДВАРИТЕЛЬНЫЕ ТРЕБОВАНИЯ:
1. Python 3.6+ для Windows
2. Tesseract OCR для Windows

ИНСТРУКЦИЯ:

1. Установите Python: https://www.python.org/downloads/
   - При установке отметьте "Add Python to PATH"

2. Установите Tesseract: https://github.com/UB-Mannheim/tesseract/wiki

3. Запустите install_dependencies.bat

4. Запустите приложение: python updated_cute_window.py

ГОРЯЧИЕ КЛАВИШИ:
- F2: Распознать текст вокруг курсора
- F3: Перевести распознанный текст
- F4: Выход

Проблемы?
- Проверьте, что Python добавлен в PATH
- Запустите командную строку от имени администратора

Приятного использования! :3
